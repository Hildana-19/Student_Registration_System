package model;

public class BachelorStudent extends Student implements Registrable {
    private String minor;

    public BachelorStudent(String name, String email, String phone, String dob, String department,
                           int completionYear, String minor) {
        super(name, email, phone, dob, "Bachelor", department, completionYear);
        this.minor = minor;
    }

    public String getMinor() {
        return minor;
    }

    public void setMinor(String minor) {
        this.minor = minor;
    }

    @Override
    public String getStudentType() {
        return "Bachelor Student";
    }

    @Override
    public String getHighestEducation() {
        return "High School Diploma";
    }

    @Override
    public String getDegree() {
        return "Bachelor";
    }

    @Override
    public String getRegistrationInfo() {
        return getName() + " - " + getDegree() + " in " + getDepartment();
    }
}
