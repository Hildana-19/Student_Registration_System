package model;

public class ExtensionStudent extends Student implements Registrable {
    private String highestEducation;
    private String additionalNotes;

    public ExtensionStudent(String name, String email, String phone, String dob, String department,
                            int completionYear, String highestEducation, String additionalNotes) {
        super(name, email, phone, dob, "Extension", department, completionYear);
        this.highestEducation = highestEducation;
        this.additionalNotes = additionalNotes;
    }

    public String getHighestEducation() {
        return highestEducation;
    }

    public void setHighestEducation(String highestEducation) {
        this.highestEducation = highestEducation;
    }

    public String getAdditionalNotes() {
        return additionalNotes;
    }

    public void setAdditionalNotes(String additionalNotes) {
        this.additionalNotes = additionalNotes;
    }

    @Override
    public String getStudentType() {
        return "Extension Student";
    }

    @Override
    public String getDegree() {
        return "Extension";
    }

    @Override
    public String getRegistrationInfo() {
        return getName() + " - Extension program (" + getDepartment() + ")";
    }
}
