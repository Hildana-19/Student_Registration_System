package model;

public interface Registrable {
    String getRegistrationInfo();  
}

