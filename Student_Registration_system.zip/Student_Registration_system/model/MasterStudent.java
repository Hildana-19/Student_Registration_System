package model;

public class MasterStudent extends Student implements Registrable {
    private String thesisTopic;

    public MasterStudent(String name, String email, String phone, String dob, String department,
                         int completionYear, String thesisTopic) {
        super(name, email, phone, dob, "Master", department, completionYear);
        this.thesisTopic = thesisTopic;
    }

    public String getThesisTopic() {
        return thesisTopic;
    }

    public void setThesisTopic(String thesisTopic) {
        this.thesisTopic = thesisTopic;
    }

    @Override
    public String getStudentType() {
        return "Master Student";
    }

    @Override
    public String getHighestEducation() {
        return "Bachelor's Degree";
    }

    @Override
    public String getDegree() {
        return "Master";
    }

    @Override
    public String getRegistrationInfo() {
        return getName() + " - Master student in " + getDepartment();
    }
}
