package ui;

public interface StudentForm {
    void displayForm();
    void submitForm();
}
